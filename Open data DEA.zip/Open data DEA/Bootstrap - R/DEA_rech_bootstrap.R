rm(list = ls())

setwd("")
.libPaths("C:\")


# library(FEAR)
library(FactoMineR)
library(Benchmarking)
library(ggplot2)
library(scales)



# help(dea.boot)
# .rs.restartR()

#importation de la base de donnees format CSV
donnees <- read.csv2("base_boot.csv",na.strings="")
y <- as.matrix(donnees$score)
x <- as.matrix(donnees$liss_DIRDA_civile_approx)
y2 <- as.matrix(donnees$score_norm)
x2 <- as.matrix(donnees$liss_norm)

# DEA simple
e.out <- dea(x,y)
eff(e.out)
dea.plot.frontier(x,y,txt=TRUE)

# Bootstrap DEA
e.boot <- dea.boot(x,y,NREP = 3000,ORIENTATION="out",RTS = "vrs")
e.boot$eff
write.table(e.boot$eff,"eff.csv",sep=";",dec=",")
e.boot$eff.bc
write.table(e.boot$eff.bc,"eff_bc.csv",sep=";",dec=",")
e.boot$conf.int
write.table(e.boot$conf.int,"eff_ic.csv",sep=";",dec=",")

# Bootstrap with normalized (PIB, pop) score and expediture
e.boot <- dea.boot(x2,y2,NREP = 3000,ORIENTATION="in",RTS = "vrs")
e.boot$eff
write.table(e.boot$eff,"eff_norm.csv",sep=";",dec=",")
e.boot$eff.bc
write.table(e.boot$eff.bc,"eff_norm_bc.csv",sep=";",dec=",")
e.boot$conf.int
write.table(e.boot$conf.int,"eff_norm_ic.csv",sep=";",dec=",")
# sans bootstrap
e.out <- dea(x2,y2,RTS="drs")
eff(e.out)
dea.plot.frontier(x2,y2,txt=TRUE)

# Bootstrap bias corrected FEAR
# e.boot_bc <- boot.fear(x,y,NREP = 3000,ORIENTATION="out",RTS = "vrs")



teBC.sfa(e.sfa)
te.sfa(e.sfa)



#     2004
donnees_04 <- read.csv2("base_boot_2004.csv",na.strings=";")
y <- as.matrix(donnees_04$score)
x <- as.matrix(donnees_04$liss_DIRDA_civile_approx)
e.boot <- dea.boot(x,y,NREP = 3000,ORIENTATION="out",RTS = "vrs")
e.boot$eff
write.table(e.boot$eff,"eff_04.csv",sep=";",dec=",")
e.boot$eff.bc
write.table(e.boot$eff.bc,"eff_bc_04.csv",sep=";",dec=",")
e.boot$conf.int
write.table(e.boot$conf.int,"eff_ic_04.csv",sep=";",dec=",")



# write.table(e.out$boot,"test.csv",sep=";",dec=",")